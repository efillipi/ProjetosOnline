CREATE DATABASE pet_pi;

USE pet_pi;

CREATE TABLE CLIENTE (
cpf CHAR(11) NOT NULL ,
nomeCli CHAR(45) NOT NULL,
telCel CHAR(15) NOT NULL,
email CHAR(100),
PRIMARY KEY (cpf)
);

CREATE TABLE RACA (
idRaca INT  NOT NULL AUTO_INCREMENT,
descr CHAR(45) NOT NULL,
PRIMARY KEY (idRaca)
);


CREATE TABLE ANIMAL (
idAni INT NOT NULL    AUTO_INCREMENT,
nomeAni CHAR(30) NOT NULL,
porte enum('Pequeno','Médio','Grande') NOT NULL,
cor CHAR(30) NOT NULL,
idRaca INT NOT NULL,
CONSTRAINT fkRACA FOREIGN KEY (idRaca) REFERENCES RACA (idRaca),
PRIMARY KEY(idAni)
);

CREATE TABLE ANIMALxCLIENTE (
cpf  CHAR(11) NOT NULL,
idAni INT NOT NULL,
CONSTRAINT fkCLIENTE FOREIGN KEY (cpf) REFERENCES CLIENTE (cpf),
CONSTRAINT fkANIMAL FOREIGN KEY (idAni) REFERENCES ANIMAL (idAni),
PRIMARY KEY (cpf, idAni)
);



CREATE TABLE SERVICO (
idServ INT NOT NULL AUTO_INCREMENT,
descr CHAR(45) NOT NULL,
valorServ DECIMAL(10,2) NOT NULL,
flag VARCHAR(10) NOT NULL,
PRIMARY KEY (idServ)
);

CREATE TABLE OS (
idOS INT NOT NULL AUTO_INCREMENT,
dataOS DATE NOT NULL,
cpf CHAR(11) NOT NULL,
idAni INT NOT NULL,
valorTotal DECIMAL(10,2) NOT NULL,
CONSTRAINT fkANIMALxCLIENTE1 FOREIGN KEY (cpf) REFERENCES ANIMALxCLIENTE (cpf),
CONSTRAINT fkANIMALxCLIENTE2 FOREIGN KEY (idAni) REFERENCES ANIMALxCLIENTE (idAni),
PRIMARY KEY (idOS)
);

CREATE TABLE ITEM (
idOS INT NOT NULL,
idServ INT NOT NULL,
valorItem DECIMAL(10,2) NOT NULL,
CONSTRAINT fkOS FOREIGN KEY (idOS) REFERENCES OS (idOS) ON DELETE CASCADE,
CONSTRAINT fkSERVICO FOREIGN KEY (idServ) REFERENCES SERVICO (idServ),
PRIMARY KEY (idOS, idServ)
);

INSERT INTO CLIENTE 
VALUES 
/*cpf, nome,tel fixo,celular,email*/
(42387883896, 'Edney FIllipi', 955403139, 'e.fillipi@gmail.com'),
(40550472827, 'Gustavo Leonardi', 989253104, 'gustavo.leonardi01@gmail.com'),
(41292700990, 'Bruna Ribeiro Lopes', 971178041, 'bruna.lopes@uscsonline.com.br'),
(32617022811, 'Priscila Paixao', 982107099, 'priscila.jesus@uscsonline.com.br');

INSERT INTO RACA 
VALUES 
(default, 'Pinscher'),
(default, 'Yorkshire'),
(default, 'Pitbull'),
(default, 'Lessie'),
(default, 'Vila Lata'),
(default, 'Golden Retriever'),
(default, 'Pitbull'),
(default, 'Gato');

INSERT INTO ANIMAL 
VALUES 
(default, 'Pity', 'Pequeno', 'Marrom', 1),
(default, 'Fred', 'Pequeno', 'Marrom', 2),
(default, 'Stark', 'Médio', 'Branco', 3),
(default, 'Panqueca', 'Médio', 'Preto', 4),
(default, 'Sturt', 'Pequeno', 'Cinza', 5),
(default, 'Clarinha', 'Pequeno', 'tricolor', 8),
(default, 'Zion', 'Grande', 'Dourado', 7),
(default, 'Jack', 'Grande', 'Branco e marron',8 ),
(default, 'Panqueca', 'Médio', 'listrado', 8);


INSERT INTO ANIMALxCLIENTE 
VALUES 
(42387883896, 9),
(42387883896, 8),
(42387883896, 7),
(42387883896, 1),
(40550472827, 2),
(40550472827, 3),
(40550472827, 4),
(41292700990, 3),
(41292700990, 6),
(41292700990, 5),
(41292700990, 7),
(32617022811, 2),
(32617022811, 1),
(32617022811, 8);

INSERT INTO SERVICO 
VALUES 
(default, 'Banho', 20.00, 'Ativo'),
(default, 'Tosa', 30.00, 'Ativo'),
(default, 'Banho & Tosa', 50.00, 'Ativo'),
(default, 'Hotelzinho', 100.00, 'Ativo'),
(default, 'Limpeza Dentes', 10.00, 'Ativo'),
(default, 'Cortar unha', 15.00, 'Ativo');


show tables;
select *from cliente;
select *from raca;
select *from animal;
select *from animalxcliente;
select *from servico;
select *from ITEM;
select *from os;
